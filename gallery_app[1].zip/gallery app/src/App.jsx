import { useState, useEffect } from "react";

function App() {
  // State banayi images ke liye
  const [images, setImages] = useState([]);
  const [loading, setLoading] = useState(true);

  // useEffect hook = page load hote hi API call kare ga
  useEffect(() => {
    fetchImages();
  }, []); // [] ka matlab sirf 1 baar chalega

  // API calling function
  const fetchImages = async () => {
    try {
      const res = await fetch("https://picsum.photos/v2/list?page=1&limit=12");
      const data = await res.json();
      setImages(data); // data state mein save kar diya
      setLoading(false);
    } catch (error) {
      console.log("Error:", error);
      setLoading(false);
    }
  };

  // Loading ke dauran ye dikhe ga
  if (loading) {
    return <h2 className="text-center mt-20 text-2xl text-gray-700">Loading images...</h2>;
  }

  return (
    <div className="min-h-screen bg-gray-100 p-8">
      <h1 className="text-4xl font-bold text-center mb-10 text-gray-800">
        📸 My Gallery App
      </h1>

      {/* Data mapping: har image ko card bana ke grid mein dikhaya */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
        {images.map((img) => (
          <div 
            key={img.id} 
            className="bg-white rounded-xl shadow-lg overflow-hidden hover:scale-105 transition duration-300"
          >
            <img 
              src={img.download_url} 
              alt={img.author}
              className="w-full h-56 object-cover"
            />
            <div className="p-4">
              <p className="font-semibold text-gray-800">By: {img.author}</p>
              <p className="text-sm text-gray-500 mt-1">Photo ID: {img.id}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;